Nay-Quan Christopher

#define Airgead_H_


class Airgead {

public:

	Airgead(double investment, double monthDeposit, double rate, int years);

	virtual ~Airgead();

	void reportNoMonthlyDeposits();

	void reportWithMonthlyDeposits();


private:

	double initialDeposit;

	double monthlyDeposit;

	double interestRate;

	int numYears;

};
